﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Notown.Data;
using Notown.Models;

namespace Notown.Controllers
{

  


  public class MusicianModelsController : Controller
  {
    private readonly ApplicationDbContext _context;

    private static List<MusicianModel> gMusicians = new List < MusicianModel >();

    private static bool firstTime = true;



    public MusicianModelsController(ApplicationDbContext context)
    {
      _context = context;


      if (firstTime)
      {
        MusicianModel myMusicianModel = new MusicianModel();
        myMusicianModel.MusicianId = 0;
        myMusicianModel.Name = "Omar Di Giorgio";
        gMusicians.Add(myMusicianModel);

        MusicianModel myMusicianModel2 = new MusicianModel();
        myMusicianModel2.MusicianId = 1;
        myMusicianModel2.Name = "Michael Jackson";
        gMusicians.Add(myMusicianModel2);

        firstTime = false;
      }

    }

    // GET: MusicianModels
    public async Task<IActionResult> Index()
    {
      // ODG: Changed to return view

      //return View(await _context.MusicianModel.ToListAsync());

      //ODG: Populate my dummy model with dummy data.
      //List<MusicianModel> lst = new List<MusicianModel>();

      return View(gMusicians);

    }

    // GET: MusicianModels/Details/5
    public async Task<IActionResult> Details(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      //ODG: Mock data.
      /*
      var musicianModel = await _context.MusicianModel
          .FirstOrDefaultAsync(m => m.MusicianId == id);
      if (musicianModel == null)
      {
        return NotFound();
      }
      */

      // ODG Showing detail for this musician.
      MusicianModel thisMusician = gMusicians.FirstOrDefault(m => m.MusicianId == id);
      return View(thisMusician);
    }

    // GET: MusicianModels/Create
    public IActionResult Create()
    {
      return View();
    }

    // POST: MusicianModels/Create
    // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
    // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("MusicianId,AddressId,Name")] MusicianModel musicianModel)
    {
      if (ModelState.IsValid)
      {
        //ODG: User my mock data entity.
        /*
        _context.Add(musicianModel);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
        */
      }


      MusicianModel newMusicianModel = new MusicianModel();
      newMusicianModel.MusicianId = musicianModel.MusicianId;
      newMusicianModel.Name = musicianModel.Name;
      if (gMusicians.Count == 0)
        newMusicianModel.MusicianId = 0;
      else
        newMusicianModel.MusicianId = gMusicians.OrderByDescending(x => x.MusicianId).First().MusicianId + 1;

      gMusicians.Add(newMusicianModel);


      return RedirectToAction("Index");
      //return View(musicianModel);
    }

    // GET: MusicianModels/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }


      /*
       ODG: Use my mock data.
      var musicianModel = await _context.MusicianModel.FindAsync(id);
      */
      MusicianModel thisMusician = gMusicians.FirstOrDefault(m => m.MusicianId == id);

      if (thisMusician == null)
      {
        return NotFound();
      }

      return View(thisMusician);
    }

    // POST: MusicianModels/Edit/5
    // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
    // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("MusicianId,AddressId,Name")] MusicianModel musicianModel)
    {
      if (id != musicianModel.MusicianId)
      {
        return NotFound();
      }


      // ODG: Using my mock data.
      /*
      if (ModelState.IsValid)
      {
        try
        {
          _context.Update(musicianModel);
          await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
          if (!MusicianModelExists(musicianModel.MusicianId))
          {
            return NotFound();
          }
          else
          {
            throw;
          }
        }
        return RedirectToAction(nameof(Index));
      }
      */
      MusicianModel thisMusician = gMusicians.FirstOrDefault(m => m.MusicianId == id);
      // Edit:
      thisMusician.Name = musicianModel.Name;
      thisMusician.AddressId = musicianModel.AddressId;

      return RedirectToAction(nameof(Index));
      //return View(musicianModel);
    }

    // GET: MusicianModels/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      // ODG: Using my own mock data.
      /*
      var musicianModel = await _context.MusicianModel
          .FirstOrDefaultAsync(m => m.MusicianId == id);
          */

      MusicianModel thisMusician = gMusicians.FirstOrDefault(m => m.MusicianId == id);

      if (thisMusician == null)
      {
        return NotFound();
      }

      return View(thisMusician);
    }

    // POST: MusicianModels/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {

      // ODG: Mock data.
      /*
      var musicianModel = await _context.MusicianModel.FindAsync(id);
      _context.MusicianModel.Remove(musicianModel);
      await _context.SaveChangesAsync();
      */

      MusicianModel thisMusician = gMusicians.FirstOrDefault(m => m.MusicianId == id);
      gMusicians.Remove(thisMusician);

      return RedirectToAction(nameof(Index));
    }

    private bool MusicianModelExists(int id)
    {
      return _context.MusicianModel.Any(e => e.MusicianId == id);
    }
  }
}
