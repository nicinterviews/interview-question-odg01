﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
  public class MusicianModel
  {

    [Key]
    public int MusicianId { get; set; }

    // Foreign key to Address table.
    public int AddressId { get; set; }
    public string Name { get; set; }
    public string SSN { get; set; }

    // ODG: Linker table needed here. Instruments played by this musician.
    public virtual ICollection<MusicianInstrumentModel> musicianInstruments { get; set; }
    public virtual ICollection<MusicianSongModel> musicianSongs { get; set; }



  }
}
