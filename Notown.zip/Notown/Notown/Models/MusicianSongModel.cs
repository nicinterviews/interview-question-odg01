﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
  public class MusicianSongModel
  {
    [Key]
    public int MusicianId { get; set; }
    public int SongId { get; set; }

    // ODG: Linker table needed here. Instruments played by this musician.
    public MusicianModel musicianModel { get; set; }
    public SongModel songModel { get; set; }



  }
}
