﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
  public class SongModel
  {
    [Key]
    public int SongId { get; set; }

    public string SongTitle { get; set; }

    public int MusicianId { get; set; }


    // ODG: Linker table needed here. Musicians that perform this song.
    //public List<MusicianModel> performers = new List<MusicianModel>();
    public virtual ICollection<AlbumSongModel> albumSongs { get; set; }

    public virtual ICollection<MusicianSongModel> musicianSongs { get; set; }



  }
}
