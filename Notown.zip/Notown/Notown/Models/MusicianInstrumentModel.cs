﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{

  public class MusicianInstrumentModel
  {
    [Key]
    public int MusicianId { get; set; }
    public int InstrumentId { get; set; }

    // ODG: Linker table needed here. Instruments played by this musician.
    public MusicianModel MusicianModel { get; set; }
    public InstrumentModel InstrumentModel { get; set; }

  }


}
