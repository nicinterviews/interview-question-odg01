﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
  public class AlbumModel
  {
    [Key]
    public int AlbumId { get; set; }
    public string AlbumTitle { get; set; }
    public DateTime CopyrightDate { get; set; }
    public string AlbumFormat { get; set; }
    public string AlbumIdentifier { get; set; }

    // Foreign key to MusicianId
    public int ProducerId { get; set; }


    // ODG: Linker table needed here. Songs that belong to this album.
    //public List<SongModel> songs = new List<SongModel>();
    public virtual ICollection<AlbumSongModel> albumSongs { get; set; }

  }
}
